##Redshift Monitoring Subscriptions API Microservice

###Description

Redshift Monitoring Subscriptions API Microservice is implemented as Spring Boot application. This Spring Boot java project mainly has following packages

1. domain - Subscription Domain object
2. repository - Database access
3. rest - RESTful API interface for the microservice

###Service Definition

####GET Subscriptions

#####Sample URL
```
http://localhost:8080/rsmonitor/api/is/subscription?subscriptionidlist=1,2,3&entityidlist=1,2,3&subscriberidlist=1,2,3,4&notificationtypelist=email,text&isenabled=true&numresults=5
```
#####Query Parameters

If multiple query parameters are provided, rules will be applied on top of one another and will further restrict the result set.

1.  subscriptionidlist

  Format: String of comma-separated values (e.g. "1,2,3")

  Functionality: This query parameter will restrict the result set to only subscriptions whose subscriptionids are listed.

2.  entityidlist

  Format: String of comma-separated values (e.g. "1,2")

  Functionality: This query parameter will restrict the result set to only subscriptions whose are based on entities the listed entity ids.  These values are entity ids.

3.  subscriberidlist

  Format: String of comma-separated values (e.g. "1,2")

  Functionality: This query parameter will restrict the result set to only subscriptions whose subsriberids are listed.  These values are app role ids of subscribers to the entity ids.

4.  notificationtypelist

  Format: String of comma-separated values (e.g. "email,text")

  Functionality: This query parameter will restrict the result set to only subscriptions whose subsriberids are listed.  These values are app role ids of subscribers to the entity ids.

5.  isenabled

  Format: boolean

  Functionality: This query parameter will be one of 2 values, "true" or "false".  If left blank all values will be returned.  If set, only enabled/disabled subscriptions will be returned.

6.  numresults

  Format: integer

  Functionality: This query parameter will restrict the number of results to the provided value.  Exceptions will be thrown if the supplied parameter cannot be parsed or if it is less than zero.  If this query parameter is not set, the default number of results will be used.


#####Response
A list of subscriptions that match the provided requested are returned.  If no matching subscriptions are found, an empty array is returned.

```
{
  "subscriptionList":
  [
    {
      "subscriptionId": 1,
      "entityid": 1,
      "subscriberid": 1,
      "notificationtype": "email",
      "isenabled": true,
      "lastupdatets": 1203960183000
    },
    {
      "subscriptionId": 1,
      "entityid": 2,
      "subscriberid": 2,
      "notificationtype": "email",
      "isenabled": true,
      "lastupdatets": 1203960183000
    }
  ]
```

####PUT New Subscriptions

#####Sample URL
```
http://localhost:8080/rsmonitor/api/is/subscription
```
#####Request Body (JSON)

```
{
    [
        {
            "entityid": 1,
            "subscriberid": 1,
            "notificationtype": "email",
            "isenabled": true,
        },
        {
            "entityid": 2,
            "subscriberid": 2,
            "notificationtype": "email",
            "isenabled": true,
        }
    ]
}
```

####POST Enable/Disable Subscription

#####Sample URL
```
http://localhost:8080/rsmonitor/api/is/subscription/
```
#####Request Body (JSON)

```
{
  "isenabled": true
  "subscriptionidlist": [
      1,
      2,
      3,
      4
  ]
}
```

###Steps to build and run

To prepare service for build:

1.  Run maven clean package from local

2.  Zip target and upload to s3

3.  clone repository to ecs server

4.  download zip target from s3

5.  unzip target in its own directory

6.  Download Dockerfile from repository to the same directory

7.  Build the service (you just need to have the Dockerfile in the repository to run Docker build process)

  ```
  docker build -t dockyard.cloud.capitalone.com/redshiftmonitorapi/subscriptionisapitest:[tag] .
  ```

8.  Push Image to Dockyard

  ```
  docker login -u ${dockyard_user}  -p ${dockyard_passwd} -e {email}  dockyard.cloud.capitalone.com
  docker push dockyard.cloud.capitalone.com/redshiftmonitorapi/subscriptionisapitest:[tag]
  ```

9.  Run the service as a Docker container

  ```docker run [image_id]```
