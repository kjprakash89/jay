zip rs_is_subscription_api_ms.zip target/*
