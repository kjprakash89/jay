package com.cof.redshiftmonitoring.api.ms.subscription.boot;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.SpringApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@ImportResource("classpath:spring/redshift-subscription-microservice-beans.xml")
@ComponentScan
@EnableAutoConfiguration
@EnableSwagger2
public class RedshiftSubscriptionMicroserviceApplication {

	public static void main(String[] args) {

		SpringApplication.run(RedshiftSubscriptionMicroserviceApplication.class, args);

	}
	
	@Bean
    public Docket subscriptionApi() {
        return new Docket(DocumentationType.SWAGGER_2)
                .select().apis(RequestHandlerSelectors.basePackage("com.cof.redshiftmonitoring.api.ms.subscription.rest"))
                //.paths(regex("/product.*"))
                .build()
                .apiInfo(metaData());
    }
 
 private ApiInfo metaData() {
        ApiInfo apiInfo = new ApiInfo(
                "Spring Boot REST API",
                "Spring Boot REST IS API for Subscription",
                "1.0",
                "Terms of service",
                new Contact("#Robot Chicken", "https://springframework.guru/", "RobotChicken@capitalone.com"),
               "Apache License Version 2.0",
                "https://www.apache.org/licenses/LICENSE-2.0");
        return apiInfo;
    }
}