package com.cof.redshiftmonitoring.api.ms.subscription.domain;

import java.util.Date;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class RedshiftSubscription {
	private int subscriptionid; 
	private int entityid; 	
	private int subscriberid; 
	private String notificationtype; 
	private boolean enabled; 
	private Date lastUpdateTs;
	
	// @return The subscriptionid
	public int getSubscriptionid() {
		return subscriptionid;
	}

	//@param subscriptionid
	public void setSubscriptionid(int subscriptionid) {
		this.subscriptionid = subscriptionid;
	}
	
	// @return The entityid
	public int getEntityid() {
		return entityid;
	}

	//@param entityid
	public void setEntityid(int entityid) {
		this.entityid = entityid;
	}

	// @return The subscriberid
	public int getSubscriberid() {
		return subscriberid;
	}

	//@param subscriberid
	public void setSubscriberid(int subscriberid) {
		this.subscriberid = subscriberid;
	}

	// @return The notificationtype
	public String getNotificationtype() {
		return notificationtype;
	}

	//@param notificationtype
	public void setNotificationtype(String notificationtype) {
		this.notificationtype = notificationtype;
	}

	// @return The enabled
	public boolean getEnabled() {
		return enabled;
	}

	//@param enabled
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	
	// @return The lastUpdateTs
	public Date getLastUpdateTs() {
		return lastUpdateTs;
	}

	//@param lastUpdateTs
	public void setLastUpdateTs(Date lastUpdateTs) {
		this.lastUpdateTs = lastUpdateTs;
	}

	@Override
	public String toString() {
		
		ObjectMapper mapper = new ObjectMapper();		
		try {
			return mapper.writeValueAsString(this);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			return null;
		}
	
	}
}