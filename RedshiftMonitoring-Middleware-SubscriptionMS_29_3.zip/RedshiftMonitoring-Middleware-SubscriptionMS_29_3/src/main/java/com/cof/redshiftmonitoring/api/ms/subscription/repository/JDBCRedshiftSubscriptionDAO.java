package com.cof.redshiftmonitoring.api.ms.subscription.repository;

import com.cof.redshiftmonitoring.api.ms.subscription.domain.RedshiftSubscription;
import com.cof.redshiftmonitoring.api.ms.subscription.rest.GetRedshiftSubscriptionRq;

import java.util.*;

public interface JDBCRedshiftSubscriptionDAO {
	
	public List<RedshiftSubscription> getSubscriptionList(GetRedshiftSubscriptionRq subscriptionRq) throws Exception;
		
}
