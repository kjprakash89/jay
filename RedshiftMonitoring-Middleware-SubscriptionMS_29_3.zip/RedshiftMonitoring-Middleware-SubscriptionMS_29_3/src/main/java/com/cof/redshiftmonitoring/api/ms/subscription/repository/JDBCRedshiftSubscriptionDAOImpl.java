package com.cof.redshiftmonitoring.api.ms.subscription.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.cof.redshiftmonitoring.api.ms.subscription.domain.RedshiftSubscription;
import com.cof.redshiftmonitoring.api.ms.subscription.rest.GetRedshiftSubscriptionRq;
import com.cof.redshiftmonitoring.api.ms.subscription.util.RedshiftSubscriptionConstants;

import java.text.SimpleDateFormat;
import java.util.*;

public class JDBCRedshiftSubscriptionDAOImpl implements JDBCRedshiftSubscriptionDAO {
	
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	/**
	 * private constructor to be called only by factory method
	 */

	private JDBCRedshiftSubscriptionDAOImpl() {
	}

	/**
	 * factory method to get an instance of GridFSImageApp class
	 */
	public static JDBCRedshiftSubscriptionDAOImpl getInstance() {
		return new JDBCRedshiftSubscriptionDAOImpl();
	}
	
	public List<RedshiftSubscription> getSubscriptionList(GetRedshiftSubscriptionRq subscriptionRq) throws Exception {
		
		List<RedshiftSubscription> subscriptionList = new ArrayList<RedshiftSubscription>();
		String sql = "SELECT * FROM redshiftmonitoring.subscription";
				
		ArrayList<String> getFields=new ArrayList<String>();
		MapSqlParameterSource params=new MapSqlParameterSource();
		
		if (subscriptionRq.getSubscriptionIdList()!=null) {
			getFields.add("id IN (:subscriptionidlist)");
			params.addValue("subscriptionidlist", subscriptionRq.getSubscriptionIdList());
		}
		
		if (subscriptionRq.getEntityIdList()!=null) {
			getFields.add("entityid IN (:entityidlist)");
			params.addValue("entityidlist", subscriptionRq.getEntityIdList());
		}
		
		if (subscriptionRq.getSubscriberIdList()!=null) {
			getFields.add("subscriberid IN (:subscriberidlist)");
			params.addValue("subscriberidlist", subscriptionRq.getSubscriberIdList());
		}
		
		if (subscriptionRq.getNotificationType()!=null) { 
			getFields.add("notificationtype IN (:notificationtypelist)");
			params.addValue("notificationtypelist", subscriptionRq.getNotificationType());
		}
		
		if (subscriptionRq.getIsEnabled()!=null) {
			getFields.add("isenabled IN (:isenabled)");
			params.addValue("isenabled", subscriptionRq.getIsEnabled());
		}
				
		if(getFields.size()>0)
		{
			sql+=" where ";
			if(getFields.size()==1)
			{
				sql+=getFields.get(0);
			}
			else
			{
				for(int i=0; i<getFields.size()-1; i++)
				{
					sql+=getFields.get(i) + " AND ";
				}
				sql+=getFields.get(getFields.size()-1);
			}
		}
		
		sql+=" ORDER BY "+ RedshiftSubscriptionConstants.getDefaultOrderByField();
		sql+=" LIMIT " + subscriptionRq.getNumResults();
			
		List<Map<String, Object>> rows = namedParameterJdbcTemplate.queryForList(sql,params.getValues());
		for (Map row : rows) {
			RedshiftSubscription result=new RedshiftSubscription();		
			result.setSubscriptionid(Integer.parseInt(String.valueOf(row.get("id"))));
		    result.setEntityid(Integer.parseInt(String.valueOf(row.get("entityid"))));	    
			result.setSubscriberid(Integer.parseInt(String.valueOf(row.get("subscriberid"))));
		    result.setNotificationtype(String.valueOf(row.get("notificationtype")));
		    result.setEnabled(Boolean.getBoolean(String.valueOf(row.get("isenabled"))));
		    result.setLastUpdateTs(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSS").parse(String.valueOf(row.get("lastupdatets"))));
		    subscriptionList.add(result);
		}		
		return subscriptionList;
	}	
}
