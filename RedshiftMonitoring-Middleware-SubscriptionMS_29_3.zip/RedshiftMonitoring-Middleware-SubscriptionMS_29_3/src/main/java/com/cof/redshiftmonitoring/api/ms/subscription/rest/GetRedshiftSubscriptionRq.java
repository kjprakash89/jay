package com.cof.redshiftmonitoring.api.ms.subscription.rest;

import java.util.List;

import org.springframework.stereotype.Component;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class GetRedshiftSubscriptionRq {
	
	private List<Integer> subscriptionIdList;
	private List<Integer> entityIdList;
	private List<Integer> subscriberIdList;
	private List<String> notificationType;
	private Boolean isEnabled;
	private int numResults;
	
	// @return The subscriptionIdList
	public List<Integer> getSubscriptionIdList() {
		return subscriptionIdList;
	}

	//@param subscriptionIdList
	public void setSubscriptionIdList(List<Integer> subscriptionIdList) {
		this.subscriptionIdList = subscriptionIdList;
	}

	// @return The entityIdList
	public List<Integer> getEntityIdList() {
		return entityIdList;
	}

	//@param entityIdList
	public void setEntityIdList(List<Integer> entityIdList) {
		this.entityIdList = entityIdList;
	}

	// @return The subscriberIdList
	public List<Integer> getSubscriberIdList() {
		return subscriberIdList;
	}

	//@param subscriberIdList
	public void setSubscriberIdList(List<Integer> subscriberIdList) {
		this.subscriberIdList = subscriberIdList;
	}

	// @return The notificationType
	public List<String> getNotificationType() {
		return notificationType;
	}

	//@param notificationType
	public void setNotificationType(List<String> notificationType) {
		this.notificationType = notificationType;
	}

	// @return The isEnabled
	public Boolean getIsEnabled() {
		return isEnabled;
	}

	//@param isEnabled
	public void setIsEnabled(Boolean isEnabled) {
		this.isEnabled = isEnabled;
	}
	
	// @return The numResults
	public int getNumResults() {
		return numResults;
	}

	//@param numResults
	public void setNumResults(int numResults) {
		this.numResults = numResults;
	}
	
	@Override
	public String toString() {
		
		ObjectMapper mapper = new ObjectMapper();		
		try {
			return mapper.writeValueAsString(this);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			return null;
		}
	
	}
}

