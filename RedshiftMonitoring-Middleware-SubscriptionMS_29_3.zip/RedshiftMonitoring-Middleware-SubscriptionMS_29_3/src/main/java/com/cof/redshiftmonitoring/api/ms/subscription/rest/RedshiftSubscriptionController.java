package com.cof.redshiftmonitoring.api.ms.subscription.rest;


import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cof.redshiftmonitoring.api.ms.subscription.service.RedshiftSubscriptionService;
import com.cof.redshiftmonitoring.api.ms.subscription.util.RedshiftSubscriptionValidator;

import io.swagger.annotations.Api;

@RestController
@RequestMapping
@Api(value="Subscription", description="Subscribe Subscription ID, Entity ID, Subscriber ID") 

public class RedshiftSubscriptionController {
	
	@Autowired
	private RedshiftSubscriptionService subscriptionService;
	
	// default value pass
	private static String health = "pass";
	
	@RequestMapping(method = RequestMethod.GET, value = "/rsmonitor/api/is/subscription")
	public GetRedshiftSubscriptionRs GetRedshiftSubscriptionsRs(@RequestParam (value="subscriptionidlist", required=false) List<Integer> subscriptionIdList,
			@RequestParam (value="entityidlist", required=false) List<Integer> entityIdList,
			@RequestParam (value="subscriberidlist", required=false) List<Integer> subscriberIdList,
			@RequestParam (value="notificationtypelist", required=false) List<String> notificationTypeList,			
			@RequestParam (value="enabled", required=false) Boolean enabled,
			@RequestParam (value="numresults", required=false) String numResults) throws Exception {
		GetRedshiftSubscriptionRq getSubscriptionRq=null;

		try {
			getSubscriptionRq=RedshiftSubscriptionValidator.validateSubscriptionRequestInfo(subscriptionIdList, entityIdList, subscriberIdList, notificationTypeList, enabled, numResults);
		} catch (Exception e) {
			throw new Exception(e);
		}
		//return subscriptionService.processGetSubscriptionList(getSubscriptionRq).getSubscriptionRs();
		return subscriptionService.processGetSubscriptionList(getSubscriptionRq);
	}
	
	// get Health for the service
	@RequestMapping(method = RequestMethod.GET, value = "/rsmonitor/api/is/subscription/health")
	public static String getHealth(HttpServletResponse response)
	{
		if(health.equalsIgnoreCase("pass"))
		{
			return "health check passed";
		}
		else
		{
			response.setStatus(503);
			return "health check failed";
		}
	}
			
	// Pass Health for the service
	@RequestMapping(method = RequestMethod.GET, value = "/rsmonitor/api/is/subscription/health/pass")
	public static String passtHealth()
	{
		health="pass";
		return "health flag set to pass";
	}
			
	// Fail Health for the service
	@RequestMapping(method = RequestMethod.GET, value = "/rsmonitor/api/is/subscription/health/fail")
	public static String failtHealth()
	{
		health="fail";
		return "health flag set to fail";
	}
}
