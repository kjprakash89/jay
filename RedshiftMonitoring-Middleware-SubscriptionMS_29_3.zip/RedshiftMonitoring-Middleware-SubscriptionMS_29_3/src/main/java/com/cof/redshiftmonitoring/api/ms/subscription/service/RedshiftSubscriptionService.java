package com.cof.redshiftmonitoring.api.ms.subscription.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cof.redshiftmonitoring.api.ms.subscription.domain.RedshiftSubscription;
import com.cof.redshiftmonitoring.api.ms.subscription.repository.JDBCRedshiftSubscriptionDAOImpl;
import com.cof.redshiftmonitoring.api.ms.subscription.rest.GetRedshiftSubscriptionRq;
import com.cof.redshiftmonitoring.api.ms.subscription.rest.GetRedshiftSubscriptionRs;


@Component
public class RedshiftSubscriptionService {

	@Autowired
	private JDBCRedshiftSubscriptionDAOImpl subscriptionDAO;
	
	public GetRedshiftSubscriptionRs processGetSubscriptionList(GetRedshiftSubscriptionRq request) throws Exception {
				
		List<RedshiftSubscription> subscriptionList=subscriptionDAO.getSubscriptionList(request);
		GetRedshiftSubscriptionRs result=new GetRedshiftSubscriptionRs();
		result.setSubscriptionRs(subscriptionList);		
		return result;
	}
}
