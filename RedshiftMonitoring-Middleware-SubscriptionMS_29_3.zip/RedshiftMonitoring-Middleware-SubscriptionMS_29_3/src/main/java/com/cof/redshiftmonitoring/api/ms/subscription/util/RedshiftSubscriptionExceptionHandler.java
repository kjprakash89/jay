package com.cof.redshiftmonitoring.api.ms.subscription.util;

import org.springframework.stereotype.Component;

@Component
public class RedshiftSubscriptionExceptionHandler {
	
	private String errMsg;
	
	public RedshiftSubscriptionExceptionHandler() {
	}
	
	public String getErrMsg() {
		return errMsg;
	}
	
	public void setErrMsg(String errMsg) {
		this.errMsg=errMsg;
	}
}