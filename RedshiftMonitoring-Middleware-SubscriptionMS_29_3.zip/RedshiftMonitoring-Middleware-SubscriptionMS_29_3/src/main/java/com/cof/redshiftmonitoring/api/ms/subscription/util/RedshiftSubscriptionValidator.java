package com.cof.redshiftmonitoring.api.ms.subscription.util;

import java.util.List;

import org.springframework.stereotype.Component;

import com.cof.redshiftmonitoring.api.ms.subscription.rest.GetRedshiftSubscriptionRq;

@Component
public class RedshiftSubscriptionValidator {
	
	private RedshiftSubscriptionValidator() {
	}
	
	public static GetRedshiftSubscriptionRq validateSubscriptionRequestInfo(List<Integer> subscriptionIdList, List<Integer> entityIdList, List<Integer> subscriberIdList, List<String> notificationTypeList, Boolean isEnabled, String numResults) throws Exception{
		GetRedshiftSubscriptionRq request=new GetRedshiftSubscriptionRq();
		validateSubscriptionIdList(subscriptionIdList, request);
		validateEntityIdList(entityIdList, request);
		validateSubscriberIdList(subscriberIdList, request);
		validateNotificationTypeList(notificationTypeList, request);
		validateEnabled(isEnabled, request);
		validateNumResults(numResults, request);
		return request;
	}
	
	private static void validateSubscriptionIdList(List<Integer> subscriptionIdList, GetRedshiftSubscriptionRq subscribeRequest) {
		if(subscriptionIdList != null) {
			subscribeRequest.setSubscriptionIdList(subscriptionIdList);	
		}
	}
	
	private static void validateEntityIdList(List<Integer> entityIdList, GetRedshiftSubscriptionRq subscribeRequest) {
		if(entityIdList != null) {
			subscribeRequest.setEntityIdList(entityIdList);	
		}	
	}
	
	private static void validateSubscriberIdList(List<Integer> subscriberIdList, GetRedshiftSubscriptionRq subscribeRequest) {
		if(subscriberIdList != null) {
			subscribeRequest.setSubscriberIdList(subscriberIdList);	
		}	
	}
	
	
	private static void validateNotificationTypeList(List<String> notificationTypeList, GetRedshiftSubscriptionRq subscribeRequest) {
		if(notificationTypeList != null) {
			subscribeRequest.setNotificationType(notificationTypeList);	
		}
	}
	
	private static void validateEnabled(Boolean isEnabled, GetRedshiftSubscriptionRq subscribeRequest) {
		if(isEnabled != null) {
			subscribeRequest.setIsEnabled(isEnabled);	
		}	
	}
		
	private static void validateNumResults(String numResults, GetRedshiftSubscriptionRq subscribeRequest) throws Exception
	{
		int resultSetSize;
		if(numResults != null) {
			try{
				resultSetSize=Integer.parseInt(numResults);
				if(resultSetSize<0) {
					System.err.println("Cannot return a result set with size less than zero.");
					throw new Exception("Cannot return a result set with size less than zero.");
				}
			}
			catch (Exception e){
				System.err.println("Could not parse numResults" + e.getMessage());
				throw new Exception("Could not parse provided numResults");
			}
		}
		else {
			resultSetSize=RedshiftSubscriptionConstants.getDefaultNumResults();
		}
		
		subscribeRequest.setNumResults(resultSetSize);
	}
}