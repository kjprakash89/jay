package com.cof.redshiftmonitoring.api.ms.subscription.domain;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.cof.redshiftmonitoring.api.ms.subscription.domain.RedshiftSubscription;

public class RedshiftSubscriptionTest {

	public static void main(String... args) {
		RedshiftSubscription subscribe = new RedshiftSubscription();
		subscribe.setEntityid(1);
		subscribe.setSubscriberid(1);
		subscribe.setNotificationtype("Email");
		subscribe.setEnabled(true);
		
		try {
			subscribe.setLastUpdateTs(new SimpleDateFormat("yyyy-MM-dd").parse("2010-11-10"));
		} catch (ParseException e) {
			e.printStackTrace();
		}

		System.out.println("subscription " + subscribe);

	}
}
