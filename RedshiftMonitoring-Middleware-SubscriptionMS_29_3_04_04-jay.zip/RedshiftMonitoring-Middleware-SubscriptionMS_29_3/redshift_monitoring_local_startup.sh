java -jar target/redshift-monitoring-api-ms-subscription-is-1.0.jar 
--server.port=8080 --pgUser=master --pgPass=Abcd1234 
--pgDbUrl=jdbc:postgresql://redshiftmonitoringpgdev-david.c4jswdfl5jxr.us-east-1.rds.amazonaws.com:5432/redshiftmonitoringpgdev
