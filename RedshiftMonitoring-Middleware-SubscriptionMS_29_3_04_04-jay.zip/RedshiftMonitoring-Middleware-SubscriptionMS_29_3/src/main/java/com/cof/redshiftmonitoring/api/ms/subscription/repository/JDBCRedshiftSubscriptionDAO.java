package com.cof.redshiftmonitoring.api.ms.subscription.repository;

import com.cof.redshiftmonitoring.api.ms.subscription.domain.RedshiftSubscription;
import com.cof.redshiftmonitoring.api.ms.subscription.rest.GetRedshiftSubscriptionRq;
import com.cof.redshiftmonitoring.api.ms.subscription.rest.PutRedshiftSubscriptionRq;

import java.util.*;

public interface JDBCRedshiftSubscriptionDAO {
	
	public List<RedshiftSubscription> getSubscriptionList(GetRedshiftSubscriptionRq subscriptionRq) throws Exception;
	
	public Boolean putSubscription(PutRedshiftSubscriptionRq subscriptionRq) throws Exception;
	
	public Boolean postToggleSubscription(Boolean enabled, List<Integer> subscriptionIds) throws Exception;
}
