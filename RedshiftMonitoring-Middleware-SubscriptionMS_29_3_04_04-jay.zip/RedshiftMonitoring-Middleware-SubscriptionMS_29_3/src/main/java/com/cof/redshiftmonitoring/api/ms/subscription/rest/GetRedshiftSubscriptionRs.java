package com.cof.redshiftmonitoring.api.ms.subscription.rest;

import java.util.List;

import org.springframework.stereotype.Component;

import com.cof.redshiftmonitoring.api.ms.subscription.domain.RedshiftSubscription;

@Component
public class GetRedshiftSubscriptionRs {
	private List<RedshiftSubscription> subscriptionList;

	// @return The subscriptionList
	public List<RedshiftSubscription> getSubscriptionRs() {
		return subscriptionList;
 	}

	//@param subscriptionList
	public void setSubscriptionRs(List<RedshiftSubscription> subscriptionList) {
		this.subscriptionList = subscriptionList;
	}
} 
