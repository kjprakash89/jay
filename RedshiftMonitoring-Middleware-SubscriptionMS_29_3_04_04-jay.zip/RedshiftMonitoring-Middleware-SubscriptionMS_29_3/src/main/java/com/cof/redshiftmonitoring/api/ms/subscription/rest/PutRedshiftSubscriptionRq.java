package com.cof.redshiftmonitoring.api.ms.subscription.rest;

import java.util.List;

import org.springframework.stereotype.Component;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class PutRedshiftSubscriptionRq {
	
	private Integer entityId;
	private Integer subscriberId;
	private String notificationType;
	private Boolean isEnabled;
	
	// @return The entityId
	public Integer getEntityId() {
		return this.entityId;
	}
	
	// @return The subscriberId
	public Integer getSubscriberId() {
		return this.subscriberId;
	}
	
	// @return The notificationType
	public String getNotificationType() {
		return this.notificationType;
	}
	
	// @return The isEnabled
	public Boolean getEnabled() {
		return this.isEnabled;
	}
	

	//@param entityId
	public void setEntityId(Integer entityId) {
		this.entityId = entityId;
	}
		
	//@param subscriberId
	public void setSubscriberId(Integer subscriberId) {
		this.subscriberId = subscriberId;
	}
	
	//@param notificationType
	public void setNotificationType(String notificationType) {
		this.notificationType = notificationType;
	}
	
	// @param isEnabled
	public void setEnabled(Boolean enabled) {
		this.isEnabled = enabled;
	}
		
	@Override
	public String toString() {
		ObjectMapper mapper = new ObjectMapper();		
		try {
			return mapper.writeValueAsString(this);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			return null;
		}
	
		
	}

}
