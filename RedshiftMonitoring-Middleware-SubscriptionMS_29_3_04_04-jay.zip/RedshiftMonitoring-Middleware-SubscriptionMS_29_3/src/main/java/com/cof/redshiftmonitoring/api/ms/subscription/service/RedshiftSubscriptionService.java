package com.cof.redshiftmonitoring.api.ms.subscription.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cof.redshiftmonitoring.api.ms.subscription.domain.RedshiftSubscription;
import com.cof.redshiftmonitoring.api.ms.subscription.repository.JDBCRedshiftSubscriptionDAOImpl;
import com.cof.redshiftmonitoring.api.ms.subscription.rest.GetRedshiftSubscriptionRq;
import com.cof.redshiftmonitoring.api.ms.subscription.rest.GetRedshiftSubscriptionRs;
import com.cof.redshiftmonitoring.api.ms.subscription.rest.PutRedshiftSubscriptionRq;


@Component
public class RedshiftSubscriptionService {

	@Autowired
	private JDBCRedshiftSubscriptionDAOImpl subscriptionDAO;
	
	public GetRedshiftSubscriptionRs processGetSubscriptionList(GetRedshiftSubscriptionRq request) throws Exception {
				
		List<RedshiftSubscription> subscriptionList=subscriptionDAO.getSubscriptionList(request);
		GetRedshiftSubscriptionRs result=new GetRedshiftSubscriptionRs();
		result.setSubscriptionRs(subscriptionList);		
		return result;
	}
	
	public Boolean processPutSubscription(PutRedshiftSubscriptionRq request) throws Exception {
		
		Boolean newSubscription = subscriptionDAO.putSubscription(request);
		
		return newSubscription;
	}
	
	public Boolean processToggleSubscription(Boolean enabled, List<Integer> subscriptionIds) throws Exception {
		
		Boolean toggleSubscription = subscriptionDAO.postToggleSubscription(enabled, subscriptionIds);
		return true;
	}
}
