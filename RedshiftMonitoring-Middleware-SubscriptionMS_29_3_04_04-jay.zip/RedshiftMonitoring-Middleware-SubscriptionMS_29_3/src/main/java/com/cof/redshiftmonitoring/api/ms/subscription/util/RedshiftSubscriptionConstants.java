package com.cof.redshiftmonitoring.api.ms.subscription.util;

import org.springframework.stereotype.Component;

@Component
public class RedshiftSubscriptionConstants {
	
	private RedshiftSubscriptionConstants() {
	}
	
	private static final int DEFAULT_NUM_RESULTS=50;
	private static final String DEFAULT_ORDER_BY_FIELD="lastupdatets";
	
	public static int getDefaultNumResults() {
		return DEFAULT_NUM_RESULTS;
	}
	
	public static String getDefaultOrderByField() {
		return DEFAULT_ORDER_BY_FIELD;
	}
	
	
	
}