package com.cof.redshiftmonitoring.api.ms.subscription.repository;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.cof.redshiftmonitoring.api.ms.subscription.domain.RedshiftSubscription;
import com.cof.redshiftmonitoring.api.ms.subscription.repository.JDBCRedshiftSubscriptionDAOImpl;

public class JDBCRedshiftSubscriptionDAOTest {

	public static void main(String... args) {
		RedshiftSubscription subscribe = new RedshiftSubscription();
		subscribe.setEntityid(1);
		subscribe.setSubscriberid(1);
		subscribe.setNotificationtype("Email");
		subscribe.setEnabled(true);
		
		try {
			subscribe.setLastUpdateTs(new SimpleDateFormat("yyyy-MM-dd").parse("2010-11-10"));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		

		// get spring context container
		ApplicationContext context = new FileSystemXmlApplicationContext(
				"target/classes/spring/redshift-incident-microservice-beans.xml");

		// get incidentDAO bean
		JDBCRedshiftSubscriptionDAOImpl subscriptionDAO = (JDBCRedshiftSubscriptionDAOImpl) context.getBean("subscriptionDAOImpl");


		((AbstractApplicationContext) context).close();

	}
}
