
// create an array with nodes
var nodes = new vis.DataSet([]);

// create an array with edges
var edges = new vis.DataSet([]);

// create a network
var container = document.getElementById('aero_canvas');

// provide the data in the vis format
var data = {
	nodes: nodes,
	edges: edges
};
var options = {
	layout: {
		hierarchical: { 
			enabled:true,
			direction: 'LR'
		}
	},
	edges:{
		arrows: {
		  to: {enabled: true, scaleFactor:0.4, type:'arrow'}
		},
		color: {
		  color:'#848484',
		  highlight:'#848484',
		  hover: '#848484',
		  inherit: 'from',
		  opacity:1.0
		},
	},
	interaction:{
		multiselect: true
	},
	manipulation: {
		enabled: true,
		addNode: false
	}
};

// initialize your network!
var network = new vis.Network(container, data, options);

function addComponent(_component_label, _component_uri){
	_current_node_id = nodes.length + 1;
	nodes.add({
		id: _current_node_id,
		label: _component_label + " - " + _current_node_id,
		shape: "image",
		image: _component_uri,
		component_class: _component_label
	});
	network.redraw();
	network.fit();
}

/* load form configs */
for (x >= localStorage.length){
	localStorage.removeItem(x)
}

localStorage.setItem("component_form_details['filter']", JSON.stringify({"filter":{ "form_layout":{"label": "","key": []}, "component": {"layout": {},"previous_component_id": 0,"next_component_id": 0}}}));
var component_form_details = localStorage.getItem("component_form_details");

/* form actions */
network.on("doubleClick", function(param){
	selected_node = param.nodes["0"];
	// get component class.
	var _component_class = nodes._data[selected_node].component_class;
	var popup_content = "";
	
	switch(_component_class){
		case "filter":
			//popup_content = component_form_details[_component_class];
			console.log(localStorage);
			/*
			"<div id='component_popup_form'><form class='form-inline'>";
			popup_content += "<div class='form-group'><label for='label'>Component Label</label><input type='text' class='form-control' /></div></form></div>";
			popup_content += 
			*/
			break;
		case "file":
			break;
		case "database":
			break;
		case "aggregate":
			break;
	}
	$("#component_popup").html(popup_content);
	$("#component_popup").show();
});
