"""
Entry point for Cloud Watch Metrics, log and RS Query analysis gatherer.
"""
import argparse
import os
import multiprocessing
from src import log
import src.modules.helpers.os_helper as os_h

import modules.GatherLogs as GatherLogs
import modules.S3 as s3_h
"""
Main method.
"""
def usage():
    """
    method to publish usage information incase of incorrect arguments.
    :return: Lines of text printed to the console.
    """
    file_name=__file__
    log.Error("Invalid usage of cloud watcher extractor \
              \nusage: \
              \n%s -config_file '' -input_dir '' -output_dir '' " % file_name)

if __name__ == "__main__":
    log.setCaller(__name__)
    multiprocessing.freeze_support()
    parser = argparse.ArgumentParser()
    parser.add_argument("-config_file", type=str, help="path and file name of config file.")
    parser.add_argument("-input_file", type=str, help="path to input file.")
    parser.add_argument("-output_dir", type=str, help="path to output file directory")
    args = parser.parse_args()

    if not (args.config_file and args.input_file and args.output_dir):
        usage()
        os._exit(1)

    # validate config file , input and output directory existence.- Future feature.
    table_details = os_h.read_file_as_dict(file_name=args.input_file)
    log_details_for_table = {k: v for k, v in table_details.iteritems() if "logs" in v["type"]}
    metric_details_for_table = {k: v for k, v in table_details.iteritems() if "metrics" in v["type"]}

    # reading data from config file.
    config_file_dy = os_h.read_file_as_dict(file_name=args.config_file)
    # setting up default s3 queue.
    s3_upload_queue = multiprocessing.Queue()

    # invoke metrics and log file gather workers.
    worker_pool = multiprocessing.Pool(processes=2)
    worker_manager = multiprocessing.Manager()
    worker_queue = worker_manager.Queue()

    # setup workers. (tuple(input), function)
    workers = [((log_details_for_table, config_file_dy), GatherLogs.gather_logs)] #, (worker_queue, s3_h.upload_to_s3)]

    for _input, _function in workers:
        worker_pool.apply_async(_function, args=_input)
    worker_pool.close()
    worker_pool.join()
    print "s3 => ", worker_queue.put("as")
        #w_input = os_h.implement_simple_worker(input=k, function_name=v, config_file=config_file_dy)
    log.Info("test ended..")


