import logging
import inspect
from logging.config import fileConfig
import os

fileConfig(os.path.join(os.path.dirname(__file__),os.pardir,os.pardir,'config','logging_config.ini'))

class Log (object):
    def __init__(self):
        self.log = logging.getLogger()
        self.level = 'INFO'
        self.caller = str(inspect.stack()[1][1:4])

    def setLevel(self, level):
        self.level = level.upper()

    def _setLevel(self):
        level = self.level
        if level == 'INFO':
            self.log.setLevel(logging.INFO)
        elif level == 'DEBUG':
            self.log.setLevel(logging.DEBUG)
        elif level == 'WARN':
            self.log.setLevel(logging.WARN)
        elif level == 'ERROR':
            self.log.setLevel(logging.ERROR)
        elif level == 'CRITICAL':
            self.log.setLevel(logging.CRITICAL)
        else:
            self.log.setLevel(logging.INFO)

    def setCaller(self,caller):
        self.caller = caller

    def Info(self, msg):
        self._log('INFO',self.caller, msg)

    def Debug(self, msg):
        self._log('DEBUG',self.caller, msg)

    def Warn(self, msg):
        self._log('WARN',self.caller, msg)

    def Error(self, msg):
        self._log('ERROR',self.caller, msg)

    def Critical(self, msg):
        self._log('CRITICAL',self.caller, msg)

    def _log(self, level, caller, msg):
        self.log = logging.getLogger(caller)
        self._setLevel()
        if level == 'INFO':
            self.log.info(msg)
        elif level == 'DEBUG':
            self.log.debug(msg)
        elif level == 'WARN':
            self.log.warn(msg)
        elif level == 'ERROR':
            self.log.error(msg)
        elif level == 'CRITICAL':
            self.log.critical(msg)
        else:
            self.log.info(msg)
