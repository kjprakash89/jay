"""
Class module to gather cloud watcher logs for the given table information.
1) read and parse the input data.
2) break data into junks to invoke threads.
3) invoke threads of get logs from aws function.

"""
import utility.Gatherer as Gatherer
from . import log
import src.modules.helpers
from helpers.aws_helper import AWSHelper as aws_h
import helpers.os_helper
import threading
import time

def worker_logic(input_data, config_file_dy):
    """
    Implementing worker logic here.
    :param input_data:
    :param config_file_dy:
    :return:
    """
    # Initializing aws class.
    CloudWatchLog = aws_h()
    aws_result = dict()
    # loop through the input data and invoke aws calls.
    for _table in input_data:
        # looping through config details for log types.
        for _log_types in config_file_dy["logs"]["types"]:
            # calling aws.
            aws_result = {_table: CloudWatchLog.get_cloud_watch_logs()}



def gather_logs(input_queue, config_file_dy):
    """
    Entry point for log gather module.
    :param input_queue:
    :param config_file_dy:
    :return: None
    """
    input_q = input_queue
    thread_q = []
    print "que -> ", input_q

    # Split data into array of n size.
    max_data = config_file_dy["logs"]["max_parallel_data"]
    split_data = []
    while True:
        if len(input_q) > max_data:
            # slice data of max_data and produce new array.
            split_data.append(dict(input_q.items()[:max_data]))
            input_q = dict(input_q.items()[max_data:])
        else:
            split_data.append(input_q)
            break

    for thread_data in split_data:
        _th = threading.Thread(target=worker_logic, args=(thread_data,config_file_dy))
        _th.daemon = False
        _th.start()
        thread_q.append(_th)

    # Waiting for all threads to perform init.
    for _thread in thread_q:
        _thread.join()

    with open("/Office/test.txt", "w") as _fp:
        _fp.write("from gather logs.")
