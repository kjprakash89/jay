"""
Author description
"""


def upload_to_s3(x):
    print "uploading to s3 bucket."