"""
Author comments.
"""
from . import log
import boto3

# setting up log name.
log.setCaller(__name__)


class AWSHelper(object):

    def __init__(self):
        pass

    def get_client(self, type):
        pass

    def get_cloud_watch_logs(self):
        pass

    def get_cloud_watch_metrics(self):
        pass
