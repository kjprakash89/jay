"""
OS module, containing file and os level interactions.
"""
import json
import collections
import multiprocessing

from . import log
# Initialize logger name.
log.setCaller(__name__)

def read_file_as_dict(file_name=None, type="json", preserve_sort=False):
    """
    Reads input file into different dictionary format.
    :param file_name:
    :param type: json
    :param preserve_sort: True | False
    :return: python dictionary containing input data.
    """
    assert file_name is not None, "Read file cannot be empty."
    try:
        with open(file_name, "r") as _fp:
            if preserve_sort:
                return json.loads(_fp.read(), object_pairs_hook=collections.OrderedDict)
            return json.loads(_fp.read())
    except:
        log.Error("Invalid or empty file -> %s " % file_name)
        raise

def implement_simple_worker(input=[], function_name=None, config_file = None):
    """
    Multiprocessing implementor, starting with simple version ( each task owning its own process )
    :param input: dictionary of table details.
    :param function_name: corresponding class to be invoked.
    :return: None.
    """
    assert function_name is not None, "Function can't be identified."
    worker_input = multiprocessing.Queue()
    worker_input.put(input)

    worker_process = multiprocessing.Process(target=function_name, args=(worker_input,config_file, ))
    worker_process.daemon = False
    worker_process.start()
    worker_process.join()
    log.Info("workers initialized")
    return worker_input
