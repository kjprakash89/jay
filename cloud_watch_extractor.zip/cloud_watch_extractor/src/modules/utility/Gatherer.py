def parse_input():
    pass

def break_data_into_junks():
    pass

def invoke_aws_gather_log():
    pass